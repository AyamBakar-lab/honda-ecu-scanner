# Honda ECU Scanner

Proyek pemindai ECU motor Honda menggunakan ESP8266, LCD I2C, dan koneksi ke HP.